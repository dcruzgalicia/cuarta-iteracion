import { MENU, type ProjectTemplate } from './engine.js';

const CONFIG = `# Colectiva: portada, autoras, palabras clave, colecciones y convocatorias.
language: es-MX
toc: false
showDate: true
license: PF-AC-PR-FA-1.0
format:
  html:
    generate: true
    pageSize: 10
    site:
      title: Mi colectiva
      description: Publicaciones de la colectiva
      style: notebook
`;

export const COLECTIVA: ProjectTemplate = {
  config: CONFIG,
  dirs: ['paginas', 'textos', 'creadoras', 'colecciones', 'convocatorias', 'anuncios', 'palabras-clave', 'listas'],
  files: {
    'index.md': '---\ntitle: Mi colectiva\n---\n\nPresenta aquí a la colectiva.\n',
    'convocatorias.md': '---\ntitle: Convocatorias\ntype: list\nfilter:\n  path: convocatorias/\norder: date-desc\n---\n\nConvocatorias abiertas.\n',
    'menu.md': MENU([
      { name: 'Inicio', url: './index.html' },
      { name: 'Convocatorias', url: './convocatorias.html' },
    ]),
    'paginas/.gitkeep': '',
    'textos/.gitkeep': '',
    'creadoras/.gitkeep': '',
    'colecciones/.gitkeep': '',
    'convocatorias/.gitkeep': '',
    'anuncios/.gitkeep': '',
    'palabras-clave/.gitkeep': '',
    'listas/.gitkeep': '',
  },
};
