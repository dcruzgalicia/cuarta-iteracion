import { Command } from 'commander';
import packageJson from '../../package.json' with { type: 'json' };
import { TEMPLATE_KINDS } from '../builder/pipeline-setup.js';
import { DPI } from '../lib/visual-diff.js';
import { runAssets } from './assets.js';
import { runBundle } from './bundle.js';
import { configHelp } from './config-help.js';
import { runCover } from './cover.js';
import {
  defaultNewDocumentPath,
  isNewDocumentType,
  NEW_DOCUMENT_TYPES,
  runBuild,
  runClean,
  runDoctor,
  runFilters,
  runInit,
  runNew,
  runValidate,
} from './dispatcher.js';
import { runMarkdown } from './markdown.js';
import { runMarkdownClean } from './markdown-clean.js';
import { runMerge } from './merge.js';
import { runCollectPdf } from './pdf.js';
import { runPost } from './post.js';
import { runPrepare } from './prepare.js';
import { runPreview } from './preview.js';
import { TEMPLATE_NAMES } from './project-templates/index.js';
import { runSnapshots, type SnapshotsOptions } from './snapshots.js';
import { runTemplate } from './template.js';
import { runTypography, type TypographyOptions } from './typography.js';

function collect(value: string, previous: string[]): string[] {
  return [...previous, value];
}

function translateCommanderError(message: string): string {
  return message
    .split('\n')
    .map((line) =>
      line
        .replace(/^error: unknown command '([^']+)'$/, "error: comando desconocido '$1'")
        .replace(/^\(Did you mean (.+)\?\)$/, '(¿Quisiste decir $1?)')
        .replace(/^error: option '([^']+)' argument missing$/, "error: falta el argumento de la opción '$1'")
        .replace(/^error: required option '([^']+)' not specified$/, "error: falta la opción requerida '$1'")
        .replace(/^error: missing required argument '([^']+)'$/, "error: falta el argumento requerido '$1'")
        .replace(/^error: unknown option '([^']+)'$/, "error: opción desconocida '$1'"),
    )
    .join('\n');
}

const EDITORIAL_COMMANDS = ['init', 'new', 'build', 'preview', 'validate', 'clean', 'doctor', 'list-filters'];

function rangoEditorial(name: string): number {
  const indice = EDITORIAL_COMMANDS.indexOf(name);
  return indice < 0 ? EDITORIAL_COMMANDS.length : indice;
}

function agruparAyuda(program: Command): void {
  for (const command of program.commands) {
    command.helpGroup(rangoEditorial(command.name()) < EDITORIAL_COMMANDS.length ? 'Flujo editorial:' : 'Comandos avanzados:');
  }
  const ordenados = [...program.commands].sort((a, b) => rangoEditorial(a.name()) - rangoEditorial(b.name()));
  (program as unknown as { commands: Command[] }).commands = ordenados;
}

export function buildProgram(): Command {
  const program = new Command();

  program
    .name(packageJson.name.replace(/-cli$/, ''))
    .version(packageJson.version, '-V, --version', 'muestra la versión')
    .helpOption('-h, --help', 'muestra la ayuda')
    .helpCommand('help [comando]', 'muestra la ayuda de un comando')
    .commandsGroup('Comandos avanzados:');
  program.addHelpText(
    'before',
    `escribir, compartir, re-existir

Construye documentos HTML, PDF, EPUB, LaTeX y Markdown a partir de archivos Markdown (pandoc + CSS propio).

Primeros pasos:
  iteraciones init blog             crea un proyecto con una plantilla (blog, libro, colectiva, repositorio)
  iteraciones new texto             crea un documento del type indicado
  iteraciones new posts/doc.md      crea un documento con frontmatter mínimo
  iteraciones build                 construye los documentos del proyecto
  iteraciones preview               construye y sirve el sitio en local
`,
  );
  program.addHelpText(
    'after',
    `
Entorno:
  NO_COLOR                  desactiva los colores (la salida no interactiva nunca los emite)
${configHelp()}
Markdown: pandoc más los filtros del paquete. "iteraciones list-filters" dice qué hace cada uno.
`,
  );
  program.option('--project-root <path>', 'directorio raíz del proyecto (por defecto: directorio actual)');
  program.configureHelp({ showGlobalOptions: true });
  program.configureOutput({ outputError: (str, write) => write(translateCommanderError(str)) });
  program.exitOverride();

  const projectRoot = (): string => program.opts().projectRoot ?? process.cwd();

  program
    .command('build [paths...]')
    .description('construye los documentos del proyecto a partir de los archivos Markdown; con paths, solo esos documentos y su cierre')
    .option('--full', 'build completo desde cero: elimina la salida anterior y la caché')
    .option('--output <path>', 'directorio de salida (por defecto: dist/files)')
    .option('--verbose', 'muestra información adicional de progreso')
    .option('--json', 'imprime el resultado como JSON en stdout (consumo programático)')
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones build                build incremental (solo archivos modificados)
  iteraciones build --full         build completo desde cero (sin caché)
  iteraciones build doc.md         construye solo ese documento (una collection arrastra sus files[] y creators)
  iteraciones build cap1.md suelto.md   varios documentos en la misma corrida
  iteraciones build --verbose      muestra información adicional de progreso
  iteraciones build --json         imprime el resultado como JSON en stdout
`,
    )
    .action(async (paths: string[], opts: { full?: boolean; output?: string; verbose?: boolean; json?: boolean }) => {
      await runBuild(projectRoot(), {
        full: opts.full,
        outputDir: opts.output,
        verbose: opts.verbose,
        json: opts.json,
        only: paths.length > 0 ? paths : undefined,
      });
    });

  program
    .command('merge <path>')
    .description('escribe la entrada exacta de pandoc de una collection en .iteraciones/collections/ (formatos: latex | html | epub | markdown)')
    .requiredOption('-f, --format <formato>', 'formato de la entrada a generar (latex | html | epub | markdown)')
    .requiredOption('-o, --output <path>', 'ruta del .md de salida')
    .option('--slug <slug>', 'slug de salida para nombrar las imágenes procesadas (por defecto se infiere del nombre de -o)')
    .addHelpText(
      'after',
      `
Siempre trabaja sobre los archivos originales de files[], nunca sobre dist/.

Ejemplos:
  iteraciones merge collection.md -f latex -o .iteraciones/collections/c.latex.md
  iteraciones merge collection.md -f html   -o .iteraciones/collections/c.html.md
`,
    )
    .action(async (path: string, opts: { output: string; format: string; slug?: string }) => {
      await runMerge(projectRoot(), path, opts);
    });

  program
    .command('template <tipo>')
    .description('escribe una plantilla de .iteraciones/templates (las que pandoc recibe por --template)')
    .option('-o, --output <path>', 'ruta de la plantilla de salida')
    .addHelpText(
      'after',
      `
Tipos: ${TEMPLATE_KINDS.join(' | ')}

Ejemplos:
  iteraciones template html                 regenera .iteraciones/templates/html.html
  iteraciones template latex -o pl.tex      la misma plantilla en otra ruta
`,
    )
    .action(async (tipo: string, opts: { output?: string }) => {
      await runTemplate(projectRoot(), tipo, opts);
    });

  program
    .command('post <tipo>')
    .description('aplica el post-proceso de iteraciones a una salida cruda de pandoc que recibe por stdin')
    .requiredOption('-o, --output <path>', 'ruta del archivo de salida')
    .option('--post <path>', 'manifiesto .iteraciones/post/<slug>.json (obligatorio en latex)')

    .option('--type <type>', 'type del documento en html: file | collection | creator (por defecto: file)')
    .addHelpText(
      'after',
      `
Tipos: html | latex

Ejemplos:
  pandoc doc.md --to html5 | iteraciones post html -o dist/doc.html
  pandoc doc.md --to latex  | iteraciones post latex --post .iteraciones/post/doc.json -o dist/doc.tex
`,
    )
    .action(async (tipo: string, opts: { output: string; post?: string; type?: string }) => {
      await runPost(projectRoot(), tipo, opts);
    });

  program
    .command('prepare')
    .description('prepara directorios para los comandos externos y deja la plantilla XMP en su slot de latexmk')
    .option('--dir <path>', 'directorio a crear (se puede repetir)', collect, [])
    .option('--xmp <path>', 'slot que recibe la plantilla pdfx.xmp (se puede repetir)', collect, [])
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones prepare --dir dist/files --dir dist/files/css
  iteraciones prepare --dir .iteraciones/tmp/pdf/slot-1 --xmp .iteraciones/tmp/pdf/slot-1
`,
    )
    .action(async (opts: { dir: string[]; xmp: string[] }) => {
      await runPrepare(projectRoot(), opts);
    });

  program
    .command('assets')
    .description('genera la hoja de estilos y copia al directorio de salida las fuentes del paquete y el logo que referencia el HTML')
    .requiredOption('-o, --output <path>', 'directorio de salida')
    .option('--licenses <nombres>', 'iconos de licencia a copiar, separados por coma')
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones assets -o dist/files
  iteraciones assets -o dist/files --licenses cc,by,nc,nd
`,
    )
    .action(async (opts: { output: string; licenses?: string }) => {
      await runAssets(projectRoot(), opts);
    });

  program
    .command('bundle')
    .description('replica en la salida los insumos del proyecto que un rebuild necesita (config, preamble*, filters, bibliografía)')
    .requiredOption('-o, --output <path>', 'directorio de salida')
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones bundle -o dist/files
`,
    )
    .action(async (opts: { output: string }) => {
      await runBundle(projectRoot(), opts);
    });

  program
    .command('markdown <path>')
    .description('escribe el markdown de dist (#2436) con las mismas salidas que usa iteraciones build')
    .requiredOption('-o, --output <path>', 'ruta del .md de salida')
    .addHelpText(
      'after',
      `
Para una collection escribe además las copias de sus miembros junto a la salida.

Ejemplos:
  iteraciones markdown doc.md        -o dist/files/doc-por-autor.md
  iteraciones markdown coleccion.md  -o dist/files/coleccion.md
`,
    )
    .action(async (path: string, opts: { output: string }) => {
      await runMarkdown(projectRoot(), path, opts);
    });

  program
    .command('clean-markdown [paths...]')
    .description('limpia el markdown de origen: quita shrink, stretch, runt, text-nowrap y espacios duros, y deja cada párrafo en una línea')
    .option('--check', 'sólo informa qué archivos cambiarían, sin escribirlos')
    .addHelpText(
      'after',
      `
Sólo toca el cuerpo: el frontmatter se conserva tal cual. Usa las mismas reglas
que el export a markdown (internal/strip-typographic.lua) y --wrap=none. Las
formas viejas que el CLI ya no reconoce se dejan como están: quítalas a mano.

Ejemplos:
  iteraciones clean-markdown                    limpia todos los markdown del proyecto
  iteraciones clean-markdown texto.md           limpia sólo ese archivo
  iteraciones clean-markdown --check texto.md   revisa sin escribir
`,
    )
    .action(async (paths: string[], opts: { check?: boolean }) => {
      await runMarkdownClean(projectRoot(), paths, opts);
    });

  program
    .command('cover <png>')
    .description('mueve la portada que pdftoppm dejó en su nombre final y retira los residuos')
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones cover dist/files/doc.png
`,
    )
    .action(async (png: string) => {
      await runCover(projectRoot(), png);
    });

  const pdf = program.command('pdf').description('operaciones sobre el PDF de trabajo de latexmk');
  pdf
    .command('collect <slot>')
    .description('retira los auxiliares del slot y deja el PDF compilado en su destino')
    .requiredOption('-o, --output <path>', 'ruta del PDF de salida')
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones pdf collect .iteraciones/tmp/pdf/slot-1 -o dist/files/doc.pdf
`,
    )
    .action(async (slot: string, opts: { output: string }) => {
      await runCollectPdf(projectRoot(), slot, opts);
    });

  const snapshots = program
    .command('snapshots')
    .description('línea base de regresión visual: imágenes de cada página para comparar contra el build (#2479)');

  snapshots
    .command('check [pdf] [reference]')
    .description(
      'compara los snapshots y el mapa de rutas de <raíz>/snapshots contra el último build, o dos PDFs entre sí; sale con exit 1 si hay regresión',
    )
    .option('--output <path>', 'directorio de salida donde están los PDFs y el HTML (por defecto: dist/files)')

    .allowExcessArguments(true)
    .addHelpText(
      'after',
      `
Requiere pdftoppm (poppler) y ImageMagick. Compara página por página sobre PNGs de ${DPI} dpi, con
fuzz 0 % y umbral 0 % de píxeles distintos: la comparación es visual y
LaTeX rinde la misma página aunque el PDF cambie de bytes, así que un píxel de diferencia es un cambio.
Las páginas del HTML se capturan con el navegador de Bun y se comparan igual.

Sin rutas compara cada PDF de --output contra sus páginas en <raíz>/snapshots/, avisa de lo que no
encaja (un PDF sin snapshot es un agregado y un snapshot sin PDF es una eliminación; ninguno de los
dos detiene, se revisan) y compara el mapa de rutas HTML contra <raíz>/snapshots/site-map.txt: una
ruta nueva o eliminada sí detiene. Con dos rutas compara pdf contra referencia y no toca los snapshots.
Una sola ruta es error: no dice contra qué comparar. Los diffs se escriben en <raíz>/diff/, que no se
versiona.

Ejemplos:
  iteraciones snapshots check                             compara snapshots/ y el mapa de rutas contra el build
  iteraciones snapshots check nuevo.pdf viejo.pdf         compara dos PDFs, sin snapshots de por medio
`,
    )
    .action(async (_pdf: string | undefined, _reference: string | undefined, opts: SnapshotsOptions, command: Command) => {
      await runSnapshots(projectRoot(), command.args, 'check', opts);
    });

  snapshots
    .command('save [pdf]')
    .description('guarda las páginas de cada PDF y el mapa de rutas HTML de la salida como línea base en snapshots/')
    .option('--output <path>', 'directorio de salida donde están los PDFs y el HTML (por defecto: dist/files)')
    .option('--site-map-only', 'sólo guarda snapshots/site-map.txt, sin renderizar PDFs')

    .allowExcessArguments(true)
    .addHelpText(
      'after',
      `
Las páginas se renderizan a ${DPI} dpi sin difuminar y se guardan en <raíz>/snapshots/ con el camino
aplanado (anexos/index.pdf → anexos--index--page-001.png), y van versionadas en git: son la línea base.
Sin ruta, además se guarda el mapa de rutas HTML de --output en <raíz>/snapshots/site-map.txt, ordenado
y con una ruta relativa por línea. Con una ruta sólo se guarda ese documento y los demás snapshots (y el
mapa) no se tocan. Sin ruta, la línea base completa avanza: los snapshots de documentos que ya no están
en la salida se retiran, y con ellos los diffs de <raíz>/diff/, que tampoco se versionan.

Además se captura cada página HTML del sitio con el navegador de Bun (Bun.WebView): quedan como
<ruta>--html--page-001.png y se comparan igual que las del PDF. La captura espera a que el texto esté
pintado, porque a medio pintar dos capturas de la misma página salen distintas. Sin navegador (o sin
línea base) se avisa y los snapshots del PDF siguen valiendo.

--site-map-only escribe únicamente el mapa de rutas HTML: útil para actualizar las rutas sin volver a
renderizar los PDFs.

No hay build incremental aquí: para saltarse un documento habría que guardar aparte qué había en el
último save, y ese registro puede quedar desfasado sin avisar.

Ejemplos:
  iteraciones snapshots save                        guarda PDFs, capturas del HTML y mapa de rutas de todo dist/files
  iteraciones snapshots save --site-map-only        sólo actualiza snapshots/site-map.txt
  iteraciones snapshots save dist/files/index.pdf   guarda las páginas de un solo documento
`,
    )
    .action(async (_pdf: string | undefined, opts: SnapshotsOptions, command: Command) => {
      await runSnapshots(projectRoot(), command.args, 'save', opts);
    });

  program
    .command('typography [paths...]')
    .description('detecta en los PDF líneas de una sola palabra, líneas consecutivas que coinciden y nombres propios cortados por el guion')
    .option('--output <path>', 'directorio de salida donde están los PDFs (por defecto: dist/files)')
    .option('--pages <páginas>', 'sólo esas páginas del PDF: 3 (esa sola), 3-80 (el rango) o una lista: 3,7,10-12')
    .option('--json', 'imprime el resultado como JSON en stdout (consumo programático)')
    .option('--rules <lista>', 'sólo esas reglas, separadas por coma (por defecto: todas)')
    .option('--fix [números]', 'corrige todo, o sólo esas incidencias: 3,5 (requiere un repositorio git)')
    .option('--clean [números]', 'limpia el párrafo de esas incidencias: 3,5 (sin números, todos)')
    .option('--exceptions <path>', 'archivo de excepciones de texto (por defecto: .typography-exceptions), ignoran casos exactos')
    .option('-i, --ignore [números]', 'guarda esas incidencias del informe como excepciones: 3,5 (sin números, todas)')
    .addHelpText(
      'after',
      `
Lee cada PDF con pdftotext -layout (poppler) y no lo modifica: sólo reporta. Sin rutas revisa
todos los PDF de --output. Sale con código 1 si encuentra alguna incidencia, para servir de puerta
en CI.

Reglas:
  single-word-line          una línea no vacía con exactamente una palabra
  consecutive-punctuation   varias líneas seguidas que todas terminan en el mismo signo de puntuación
  repeated-first-letter     varias líneas seguidas que empiezan por la misma letra
  repeated-last-letter      varias líneas seguidas que terminan por la misma letra
  hyphenated-proper-noun    un nombre propio partido por el guion al final de la línea
  stretched-line            una línea justificada con los espacios estirados (≥1.80×)
  shrunk-line               una línea justificada con los espacios comprimidos (≤0.70×)
  river                     un canal blanco de 3 o más líneas consecutivas

Las reglas de espaciado (stretched-line, shrunk-line, river) sólo se reportan: --fix y --clean
no las tocan.

El número de línea reinicia en cada página. Una línea vacía y el final de página cortan la
consecutividad: la última línea de una página nunca se compara con la primera de la siguiente.
Todas las líneas se comparan, sin importar su longitud: los casos que no quieras ver se guardan
en el archivo de excepciones con --ignore, usando el número que trae el informe.

Ejemplos:
  iteraciones typography                                revisa los PDF de dist/files
  iteraciones typography dist/files/libro.pdf           revisa uno
  iteraciones typography dist/files/libro.pdf --pages 3 sólo la página 3
  iteraciones typography --pages 3-80                   sólo esas páginas
  iteraciones typography --pages 3,7,10-12              sólo esas páginas, sueltas o en tramos
  iteraciones typography --rules single-word-line            sólo las líneas de una sola palabra
  iteraciones typography --rules repeated-first-letter,repeated-last-letter   sólo las letras
  iteraciones typography --rules stretched-line,shrunk-line,river            sólo el espaciado
  iteraciones typography --ignore 3,5                   guarda esas incidencias como excepciones
  iteraciones typography --ignore                       guarda todas las del informe
  iteraciones typography --fix 3,5                      corrige sólo esas incidencias
  iteraciones typography --clean 3,5                    limpia el párrafo de esas incidencias
  iteraciones typography --clean                        limpia el párrafo de todas
  iteraciones typography --json                         imprime el resultado como JSON

El informe da siempre la página del PDF, no el folio impreso, que puede venir en romanos o
empezar en otro punto. El folio sí se usa, para no reportarlo como línea de una palabra.
`,
    )
    .action(async (paths: string[], opts: TypographyOptions) => {
      await runTypography(projectRoot(), paths, opts);
    });

  program
    .command('init [tipo]')
    .description('crea el .gitignore mínimo; con una plantilla crea un proyecto compilable, y con "sveltia" agrega el admin')
    .addHelpText(
      'after',
      `
Plantillas: ${TEMPLATE_NAMES.join(' | ')}

Ejemplos:
  iteraciones init                  prepara el .gitignore del proyecto en el directorio actual
  iteraciones init blog             crea un proyecto de blog sin contenido de ejemplo
  iteraciones init libro            crea un proyecto de libro con PDF y EPUB
  iteraciones init colectiva        crea portada, menú y carpetas para una colectiva
  iteraciones init repositorio      crea catálogo, metadatos y licencias
  iteraciones init sveltia          agrega el admin de Sveltia y el layout para publicarlo
`,
    )
    .action(async (tipo?: string) => {
      await runInit(projectRoot(), tipo);
    });

  program
    .command('validate')
    .description('valida el frontmatter, la configuración y la accesibilidad básica del HTML ya construido')
    .option('--json', 'imprime el resultado como JSON en stdout (consumo programático)')
    .addHelpText(
      'after',
      `
Además revisa los HTML de la salida si ya existe un build: imágenes sin alt o sin
dimensiones, enlaces sin nombre y saltos de encabezado. Esos avisos no bloquean.

Ejemplos:
  iteraciones validate         valida el frontmatter, la configuración y la accesibilidad
  iteraciones validate --json  imprime el resultado como JSON en stdout
`,
    )
    .action(async (opts: { json?: boolean }) => {
      await runValidate(projectRoot(), { json: opts.json });
    });

  program
    .command('preview [paths...]')
    .description('construye, sirve el sitio y el admin en local, y reconstruye con cada cambio; Ctrl+C para salir')
    .option('--verbose', 'muestra información adicional de progreso')
    .option('--port <puerto>', 'puerto del servidor local (por defecto: 4321)')
    .addHelpText(
      'after',
      `
El servidor sirve dist/files y /admin/; el navegador recarga cuando termina un build.
Un cambio durante un build no se pierde: el build siguiente lo recoge.
Acepta los mismos paths que build.

Ejemplos:
  iteraciones preview                 construye, sirve y reconstruye el proyecto entero
  iteraciones preview posts/x.md      reconstruye solo ese documento
  iteraciones preview --port 8080     sirve en otro puerto
  iteraciones preview --verbose       muestra el detalle de cada build
`,
    )
    .action(async (paths: string[], opts: { verbose?: boolean; port?: string }) => {
      const port = opts.port === undefined ? undefined : Number.parseInt(opts.port, 10);
      if (port !== undefined && (!Number.isInteger(port) || port < 0 || port > 65535)) {
        program.error(`puerto inválido: "${opts.port}"`);
      }
      await runPreview(projectRoot(), { verbose: opts.verbose, only: paths.length > 0 ? paths : undefined, port });
    });

  program
    .command('doctor')
    .description('verifica el entorno de build')
    .option('--info', 'muestra también la configuración del proyecto')
    .option('--json', 'imprime el resultado como JSON en stdout (consumo programático)')
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones doctor                verifica pandoc, motor LaTeX y permisos
  iteraciones doctor --info         además, muestra la configuración del proyecto
  iteraciones doctor --json         imprime el resultado como JSON en stdout
  iteraciones doctor --info --json  incluye la configuración en el JSON
`,
    )
    .action(async (opts: { info?: boolean; json?: boolean }) => {
      await runDoctor(projectRoot(), { info: opts.info, json: opts.json });
    });

  program
    .command('new [tipoOrPath] [path]')
    .description('crea un archivo Markdown con el frontmatter de su type; con una ruta suelta conserva el frontmatter mínimo')
    .option('-t, --title <title>', 'título del documento (por defecto: inferido del nombre del archivo)')
    .addHelpText(
      'after',
      `
Types: ${NEW_DOCUMENT_TYPES.join(' | ')}

Ejemplos:
  iteraciones new texto                    crea texto.md con type file y date
  iteraciones new creadora ana-ruiz        crea ana-ruiz.md con type creator y name
  iteraciones new lista lectura            crea lectura.md con type list
  iteraciones new posts/mi-articulo.md     crea el archivo con title, date y frontmatter mínimo
  iteraciones new --title "Mi artículo" posts/mi-articulo.md   usa un título explícito
`,
    )
    .action(async (tipoOrPath: string | undefined, path: string | undefined, opts: { title?: string }) => {
      if (tipoOrPath === undefined) {
        program.error("error: falta el argumento requerido 'path'");
        return;
      }
      const type = isNewDocumentType(tipoOrPath) ? tipoOrPath : undefined;
      const destino = type === undefined ? tipoOrPath : (path ?? defaultNewDocumentPath(type));
      await runNew(projectRoot(), destino, { title: opts.title, type });
    });

  program
    .command('clean')
    .description('elimina el directorio de salida (dist/) y la caché (.iteraciones)')
    .option('--json', 'imprime el resultado como JSON en stdout (consumo programático)')
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones clean         elimina dist/ y .iteraciones/ del proyecto
  iteraciones clean --json  imprime el resultado como JSON en stdout
`,
    )
    .action(async (opts: { json?: boolean }) => {
      await runClean(projectRoot(), { json: opts.json });
    });

  program
    .command('list-filters')
    .description('lista los filters Lua y los filters de preámbulo disponibles con su estado')
    .option('--verbose', 'incluye la descripción completa de cada filtro')
    .option('--json', 'imprime el resultado como JSON en stdout (consumo programático)')
    .addHelpText(
      'after',
      `
Ejemplos:
  iteraciones list-filters         lista filters y preamble filters con su estado
  iteraciones list-filters --json  imprime el resultado como JSON en stdout
`,
    )
    .action((options: { verbose?: boolean; json?: boolean }) => runFilters(projectRoot(), options));

  agruparAyuda(program);
  return program;
}
