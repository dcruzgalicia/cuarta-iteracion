import { mkdir, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { BuildError, translateSystemError } from '../lib/errors.js';
import { applyCreatorTitle, parseFrontmatterRecord, splitFrontmatter } from '../lib/frontmatter.js';
import { fmStringList, fmTrimmedString } from '../lib/frontmatter-fields.js';
import type { BuildMetadata } from './build-planner.js';
import { parseAuthors } from './discover-frontmatter.js';
import type { FormatsLink } from './html-composer.js';
import { docProducesFormat, primaryOutputExtension } from './output-layout.js';
import type { BuildDocument } from './types.js';

export function espaciosNormales(texto: string): string {
  return texto.replace(/&nbsp;|&#160;|&#xa0;|\u00a0/gi, ' ');
}

export async function writeOutput(path: string, content: string): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  await Bun.write(path, content);
}

export async function writeExclusive(path: string, content: string): Promise<boolean> {
  try {
    await writeFile(path, content, { encoding: 'utf8', flag: 'wx' });
    return true;
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'EEXIST') return false;
    throw err;
  }
}

export async function writeIfChanged(path: string, content: string): Promise<void> {
  if (await Bun.file(path).exists()) {
    try {
      const existing = await Bun.file(path).text();
      if (existing === content) return;
    } catch {}
  }
  await writeOutput(path, content);
}

export async function readMarkdownOrWarn(doc: BuildDocument): Promise<string> {
  let content: string;
  try {
    content = await Bun.file(doc.filePath).text();
  } catch (err) {
    throw new BuildError(`no se pudo leer "${doc.filePath}": ${translateSystemError(err, 'verifica que el nombre del archivo sea correcto')}`);
  }
  const { yaml, body } = splitFrontmatter(content);
  const sinCuerpo =
    doc.frontmatter.type !== 'collection' &&
    doc.frontmatter.type !== 'intervention' &&
    doc.frontmatter.type !== 'list' &&
    doc.frontmatter.type !== 'menu';
  if (!body.trim() && sinCuerpo) {
    throw new BuildError(
      yaml !== undefined
        ? `"${doc.filePath}" no tiene contenido después del frontmatter; agrega un body para proceder con el build`
        : `"${doc.filePath}" está vacío; agrega un body para proceder con el build`,
    );
  }
  return content;
}

const FORMAT_LINK_META = {
  pdf: { name: 'PDF' },
  epub: { name: 'EPUB' },
  latex: { name: 'LaTeX' },
  markdown: { name: 'Markdown' },
} as const;

export function formatLinksFor(plan: BuildMetadata, outSlug: string, type?: string): FormatsLink[] {
  return (Object.keys(FORMAT_LINK_META) as FormatsLink['key'][])
    .filter((key) => plan.activeFormats[key])
    .filter((key) => docProducesFormat(type, key))
    .map((key) => ({
      href: `./${outSlug}${primaryOutputExtension(key)}`,
      key,
      ...FORMAT_LINK_META[key],
    }));
}

export function parseFileFrontmatter(
  content: string,
  label: string,
): {
  title: string;
  creator: string[];
  subtitle: string | undefined;
  date: string | undefined;
  type: string | undefined;
  lineLength: number | undefined;
  pages: number | undefined;
  letterhead: string[];
  letterheadHeight: string | undefined;
  image: string | undefined;
  frontCover: string | undefined;
  backCover: string | undefined;
  body: string;
} {
  const { yaml, body } = splitFrontmatter(content);
  if (!yaml) {
    return {
      title: '',
      creator: [],
      subtitle: undefined,
      date: undefined,
      type: undefined,
      lineLength: undefined,
      pages: undefined,
      letterhead: [],
      letterheadHeight: undefined,
      image: undefined,
      frontCover: undefined,
      backCover: undefined,
      body,
    };
  }
  const parsed = parseFrontmatterRecord(yaml, label);
  applyCreatorTitle(parsed);
  return {
    title: typeof parsed.title === 'string' ? parsed.title : '',
    creator: parseAuthors(parsed.creator),
    subtitle: typeof parsed.subtitle === 'string' ? parsed.subtitle : undefined,
    date: typeof parsed.date === 'string' ? parsed.date : undefined,
    type: typeof parsed.type === 'string' ? parsed.type : undefined,
    lineLength: typeof parsed.lineLength === 'number' ? parsed.lineLength : undefined,
    pages: typeof parsed.pages === 'number' ? parsed.pages : undefined,
    letterhead: fmStringList(parsed.letterhead) ?? [],
    letterheadHeight: fmTrimmedString(parsed.letterheadHeight),
    image: fmTrimmedString(parsed.image),
    frontCover: fmTrimmedString(parsed.frontCover),
    backCover: fmTrimmedString(parsed.backCover),
    body,
  };
}
