import { exists, readdir, realpath, rm } from 'node:fs/promises';
import { cpus } from 'node:os';
import { basename, dirname, isAbsolute, join, normalize, relative } from 'node:path';
import { loadSiteConfig } from '../config/config-loader.js';
import type { SiteConfig } from '../config/config-schema.js';
import { type ActiveFormats, computeActiveFormats, type FormatKey, resolveDisabledPreambleConfig } from '../config/site-config.js';
import { BuildError, ConfigError } from '../lib/errors.js';
import { parseYamlWithPosition, splitFrontmatter } from '../lib/frontmatter.js';
import { resolveBooleanField } from '../lib/frontmatter-fields.js';
import { logWarning, runWithWarningSink } from '../lib/logger.js';
import { getPandocVersion } from '../lib/pandoc-runner.js';
import { posix } from '../lib/paths.js';
import { plural } from '../lib/plural.js';
import { abortScriptCapture, beginScriptCapture, commitScriptCapture } from '../lib/script-recorder.js';
import { buildAssets, copyAdminSite } from './build-assets.js';
import { type BuildMetadata, computeBuildMetadata, computeWorkSets, FORMAT_TO_WORK, type WorkSets } from './build-planner.js';
import { writeBundle } from './bundle-dist.js';
import { cleanupCoverImages, cleanupDeletedFiles, cleanupRemovedFormats, cleanupSlugChanges, hasLegacyAssetLayout } from './cleanup.js';
import { resolveCollectionFiles } from './collection-files.js';
import { buildDocsFromIndex, discover, htmlSlugFor, resolveDiscoverSlugs } from './discover.js';
import { parseAuthors } from './discover-frontmatter.js';
import { projectFilterNames, validateDisabledFilters } from './filter-resolver.js';
import { resetImageCache } from './image-processor.js';
import { selectListMembers } from './list-filter.js';
import { DIST_FILES_DIR, docProducesFormat, primaryOutputExtension } from './output-layout.js';
import { type PdfxCacheHandle, runPdfxOutputValidation } from './pdfx-check.js';
import { documentPipeline } from './pipeline.js';
import {
  collectionCreatorDocPaths,
  creatorDocPathsFor,
  iconosDeLicencias,
  licenciaEfectiva,
  resolveCollectionCreatorDocs,
} from './pipeline-formats.js';
import { resolveEffectiveDisabledPreamble, validateDisabledPreambleFilters, validatePreambleDependencies } from './preamble-loader.js';
import { validateConfigFilePaths, validateConfigRules } from './project-validator.js';
import type { BuildState } from './state-serialize.js';
import { loadStateFile, persistCompletedState } from './state-serialize.js';
import { assertBuildTools } from './tool-preflight.js';
import type { BuildContext, BuildDocument, BuildReporter, DiscoveryEntry } from './types.js';

const silentReporter: BuildReporter = {
  setFormats(): void {},
  startPhase(): void {},
  reportFile(): void {},
  completePhase(): void {},
  log(): void {},
  addWarning(): void {},
  addSummaryLine(): void {},
  showCleanup(): void {},
  startLightFormats(): void {},
  finish(): Promise<void> {
    return Promise.resolve();
  },
  fail(): Promise<void> {
    return Promise.resolve();
  },
};

export const EMPTY_PROJECT_WARNING_CODE = '[empty-project]';

const EMPTY_PROJECT_WARNING_NO_DOCS = 'No se encontraron documentos Markdown en el proyecto.';
const EMPTY_PROJECT_WARNING_INIT = "Crea un archivo .md con frontmatter o ejecuta 'iteraciones init sveltia'.";

export interface BuildOptions {
  outputDir?: string;
  full?: boolean;
  verbose?: boolean;
  json?: boolean;

  only?: string[];
}

function selectionOf(options: BuildOptions): string[] | undefined {
  return options.only !== undefined && options.only.length > 0 ? options.only : undefined;
}

async function assertSelectionCompatible(options: BuildOptions, root: string): Promise<void> {
  if (selectionOf(options) === undefined) return;
  if (options.full) {
    throw new BuildError(
      'build --full y los paths seleccionados son incompatibles: --full borra la salida y la caché enteras. Quita --full para construir solo esos documentos.',
    );
  }
  if (await hasLegacyAssetLayout(options.outputDir ?? join(root, DIST_FILES_DIR))) {
    throw new BuildError(
      'la salida usa el layout de assets anterior (#2450), que exige reconstruir todo el proyecto: ejecuta `iteraciones build --full` y vuelve a pasar los paths después.',
    );
  }
}

interface BuildSummary {
  processed: number;
  cached: number;
  formats: string[];
  outputDir: string;
  invalidations: string[];

  selected?: string[];
}

export async function build(cwd: string, options: BuildOptions = {}, reporter: BuildReporter = silentReporter): Promise<void> {
  const root = await realpath(cwd).catch(() => cwd);

  await assertSelectionCompatible(options, root);

  if (!options.full && (await hasLegacyAssetLayout(options.outputDir ?? join(root, DIST_FILES_DIR)))) {
    options.full = true;
    reporter.log('layout de assets anterior detectado en la salida (#2450) → se reconstruye la salida completa');
  }
  const pandocVersion = await getPandocVersion();

  const startedAt = performance.now();
  const progress = reporter;
  let result: BuildSummary | null = null;
  try {
    if (options.verbose) {
      result = await runBuild(root, options, progress, pandocVersion);
    } else {
      result = await runWithWarningSink(
        (message) => progress.addWarning(message),
        () => runBuild(root, options, progress, pandocVersion),
      );
    }
  } catch (err) {
    abortScriptCapture();
    await progress.fail();
    if (options.full) {
      const outputDir = options.outputDir ?? join(root, DIST_FILES_DIR);
      await rm(outputDir, { recursive: true, force: true });
    }
    throw err;
  }
  await commitScriptCapture();
  if (options.json && result !== null) {
    process.stdout.write(`${JSON.stringify({ ...result, durationMs: Math.round(performance.now() - startedAt) })}\n`);
  }
}

async function resolveEffectiveConfig(cwd: string): Promise<{ siteConfig: SiteConfig; effectiveDisabledPreamble: string[] }> {
  const siteConfig = await loadSiteConfig(cwd);
  validateDisabledFilters(siteConfig.disabledFilters, join(cwd, 'iteraciones.config.yaml'), projectFilterNames(siteConfig.luaFilters));
  const effectiveDisabledPreamble = resolveEffectiveDisabledPreamble(resolveDisabledPreambleConfig(siteConfig));
  validateDisabledPreambleFilters(effectiveDisabledPreamble);
  for (const issue of [...validateConfigRules(siteConfig), ...(await validateConfigFilePaths(cwd, siteConfig))]) {
    if (issue.severity === 'error') {
      throw new ConfigError(`iteraciones.config.yaml: ${issue.message}`, join(cwd, 'iteraciones.config.yaml'));
    }
    logWarning(`iteraciones.config.yaml: ${issue.message}`, 'config');
  }
  for (const issue of validatePreambleDependencies(effectiveDisabledPreamble)) {
    if (issue.severity === 'error') {
      throw new BuildError(`dependencia de preamble filters: ${issue.message}`);
    }
    logWarning(issue.message, 'config');
  }
  return { siteConfig, effectiveDisabledPreamble };
}

const INVALIDATION_FLAGS: { test: (plan: BuildMetadata) => boolean; log: string; label: string }[] = [
  { test: (p) => p.filtersInvalidated, log: 'Filters modificados — reprocesando todos los documentos', label: 'filters' },
  { test: (p) => p.bibInvalidated, log: 'Bibliografía modificada — regenerando las exportaciones', label: 'bibliografía' },
  { test: (p) => p.formatInvalidated.print, log: 'Configuración PDF/LaTeX modificada — regenerando LaTeX/PDF', label: 'configuración PDF/LaTeX' },
  { test: (p) => p.formatInvalidated.html, log: 'Configuración HTML modificada — regenerando páginas HTML', label: 'configuración HTML' },
  { test: (p) => p.formatInvalidated.epub, log: 'Configuración EPUB modificada — regenerando EPUBs', label: 'configuración EPUB' },
  {
    test: (p) => p.formatInvalidated.markdown,
    log: 'Configuración Markdown modificada — regenerando exports Markdown',
    label: 'configuración Markdown',
  },
];

function logInvalidations(plan: BuildMetadata, log: (msg: string) => void): void {
  if (plan.newFormats.length > 0) {
    log(`Nuevos formatos detectados: ${plan.newFormats.join(', ')}. Generando sus salidas para todos los documentos.`);
  }
  if (plan.removedFormats.length > 0) {
    log(`Formatos eliminados: ${plan.removedFormats.join(', ')}. Limpiando archivos de dist.`);
  }
  for (const flag of INVALIDATION_FLAGS) if (flag.test(plan)) log(flag.log);
}

function collectInvalidations(plan: BuildMetadata, outputDirChanged: boolean): string[] {
  const invalidations: string[] = [];
  if (outputDirChanged) invalidations.push('directorio de salida');
  for (const flag of INVALIDATION_FLAGS) if (flag.test(plan)) invalidations.push(flag.label);
  for (const format of plan.newFormats) invalidations.push(`formato nuevo: ${format}`);
  return invalidations;
}

export async function aggregateCollectionCreators(entry: { files?: string[]; fm?: Record<string, unknown> }, cwd: string): Promise<string[]> {
  const { with: withCreator, without: withoutCreator } = await countCreatorsByFile(entry.files ?? [], cwd);
  const fallback = parseAuthors(entry.fm?.collectionCreator);
  if (withCreator.length === 0 && fallback.length > 0) return fallback.sort((a, b) => a.localeCompare(b, 'es'));
  const aggregated = new Set<string>();
  for (const c of withCreator) aggregated.add(c);
  addAnonymousFallback(aggregated, withoutCreator, entry.files?.length ?? 0);
  return [...aggregated].sort((a, b) => a.localeCompare(b, 'es'));
}

async function countCreatorsByFile(files: string[], cwd: string): Promise<{ with: string[]; without: number }> {
  const withCreator: string[] = [];
  let without = 0;
  for (const file of files) {
    try {
      const text = await Bun.file(join(cwd, file)).text();
      const { yaml } = splitFrontmatter(text);
      if (!yaml) {
        without++;
        continue;
      }
      const { value, error } = parseYamlWithPosition(yaml);
      if (error) {
        logWarning(`no se pudo leer el frontmatter de "${file}" para contar creadores: ${error}`, 'merge');
        without++;
        continue;
      }
      const parsed = (value ?? {}) as Record<string, unknown>;
      if (parsed.type === 'intervention') continue;
      const creators = parseAuthors(parsed.creator);
      if (creators.length > 0) {
        withCreator.push(...creators);
      } else {
        without++;
      }
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') continue;
      logWarning(`no se pudo leer el frontmatter de "${file}" para contar creadores: ${(err as Error).message}`, 'merge');
      without++;
    }
  }
  return { with: withCreator, without };
}

function addAnonymousFallback(aggregated: Set<string>, filesWithoutCreator: number, totalFiles: number): void {
  if (filesWithoutCreator === 0) return;
  if (filesWithoutCreator === totalFiles) {
    aggregated.add(totalFiles > 1 ? 'Anónimas' : 'Anónima');
  } else {
    aggregated.add('Anónima');
  }
}

function assertNoNestedCollections(resolved: string[], relativePath: string, discoveryIndex: Map<string, DiscoveryEntry>): void {
  for (const relPath of resolved) {
    if (discoveryIndex.get(relPath)?.type === 'collection') {
      throw new BuildError(
        `collection "${relativePath}": "${relPath}" está en su files[] y también es una collection; una collection no puede formar parte de otra. Quítalo de files[].`,
      );
    }
  }
}

function resolveListMembers(
  relativePath: string,
  entry: DiscoveryEntry,
  discoveryIndex: Map<string, DiscoveryEntry>,
  owners: Map<string, string[]>,
): void {
  const members = selectListMembers(relativePath, entry.fm ?? {}, discoveryIndex);
  entry.files = members;
  if (entry.fm) entry.fm.files = members;
  for (const member of members) {
    const lista = owners.get(member);
    if (lista === undefined) owners.set(member, [relativePath]);
    else lista.push(relativePath);
  }
}

async function resolveCollectionMembers(
  relativePath: string,
  entry: DiscoveryEntry,
  discoveryIndex: Map<string, DiscoveryEntry>,
  cwd: string,
  creatorOwners: Map<string, string[]>,
  owners: Map<string, string[]>,
): Promise<void> {
  const resolved = await resolveCollectionFiles(entry.files ?? [], relativePath, cwd);
  assertNoNestedCollections(resolved, relativePath, discoveryIndex);
  entry.files = resolved;
  if (entry.fm) entry.fm.files = resolved;
  entry.aggregatedCreator = await aggregateCollectionCreators(entry, cwd);

  const previos = entry.creatorDocs ?? [];
  entry.creatorDocs = await collectionCreatorDocPaths(resolved, entry.fm ?? {}, discoveryIndex, cwd);
  for (const creatorDoc of new Set([...previos, ...entry.creatorDocs])) {
    const list = creatorOwners.get(creatorDoc);
    if (list === undefined) creatorOwners.set(creatorDoc, [relativePath]);
    else list.push(relativePath);
  }
  for (const member of resolved) {
    const lista = owners.get(member);
    if (lista === undefined) owners.set(member, [relativePath]);
    else lista.push(relativePath);
  }
}

function creatorDocsDe(entry: DiscoveryEntry, discoveryIndex: Map<string, DiscoveryEntry>): string[] {
  const type = entry.type ?? 'file';
  if (type !== 'file') return [];
  const nombres = [...entry.creator, ...parseAuthors(entry.fm?.contributor)];
  return creatorDocPathsFor(nombres, discoveryIndex);
}

function anotaCreadoras(
  relativePath: string,
  entry: DiscoveryEntry,
  discoveryIndex: Map<string, DiscoveryEntry>,
  creatorOwners: Map<string, string[]>,
): void {
  for (const creatorDoc of creatorDocsDe(entry, discoveryIndex)) {
    const list = creatorOwners.get(creatorDoc);
    if (list === undefined) creatorOwners.set(creatorDoc, [relativePath]);
    else list.push(relativePath);
  }
}

function fechaMaxima(discoveryIndex: Map<string, DiscoveryEntry>, rutas: string[]): { texto: string; valor: number } | undefined {
  let maxima: { texto: string; valor: number } | undefined;
  for (const ruta of rutas) {
    const fecha = discoveryIndex.get(ruta)?.date;
    if (fecha === undefined) continue;
    const valor = Date.parse(fecha);
    if (Number.isNaN(valor)) continue;
    if (maxima === undefined || valor > maxima.valor) maxima = { texto: fecha, valor };
  }
  return maxima;
}

const SIN_PUBLICACION = '0000-01-01';

function asignaListDate(discoveryIndex: Map<string, DiscoveryEntry>, creatorOwners: Map<string, string[]>): void {
  for (const [creatorPath, entry] of discoveryIndex) {
    if (entry.type !== 'creator') continue;
    const propias = (creatorOwners.get(creatorPath) ?? []).filter((ruta) => {
      const dueno = discoveryIndex.get(ruta);
      return dueno !== undefined && (dueno.type === undefined || dueno.type === 'file');
    });
    const maxima = fechaMaxima(discoveryIndex, propias) ?? fechaMaxima(discoveryIndex, creatorOwners.get(creatorPath) ?? []);
    entry.listDate = maxima?.texto ?? SIN_PUBLICACION;
  }
}

export async function postProcessCollections(
  discoveryIndex: Map<string, DiscoveryEntry>,
  cwd: string,
): Promise<{ creatorOwners: Map<string, string[]>; collectionOwners: Map<string, string[]> }> {
  const creatorOwners = new Map<string, string[]>();
  const owners = new Map<string, string[]>();

  for (const [relativePath, entry] of discoveryIndex) {
    if (entry.type !== 'collection' || !entry.files) continue;
    await resolveCollectionMembers(relativePath, entry, discoveryIndex, cwd, creatorOwners, owners);
  }

  for (const [relativePath, entry] of discoveryIndex) {
    anotaCreadoras(relativePath, entry, discoveryIndex, creatorOwners);
  }

  const collectionOwners = new Map(owners);
  for (const [creatorDoc, collections] of creatorOwners) {
    const list = collectionOwners.get(creatorDoc);
    if (list === undefined) collectionOwners.set(creatorDoc, [...collections]);
    else list.push(...collections);
  }

  asignaListDate(discoveryIndex, creatorOwners);

  for (const [relativePath, entry] of discoveryIndex) {
    if (entry.type === 'list') resolveListMembers(relativePath, entry, discoveryIndex, owners);
  }

  for (const [ruta, entry] of discoveryIndex) {
    const contenedores = owners.get(ruta);
    if (contenedores === undefined) continue;
    entry.containedBy = [...contenedores].sort((a, b) => a.localeCompare(b, 'es'));
  }

  return { creatorOwners, collectionOwners };
}

function expandCollectionChanges(changed: Set<string>, owners: Map<string, string[]>): void {
  const queue = [...changed];
  const seen = new Set(queue);
  while (queue.length > 0) {
    const path = queue.pop();
    if (path === undefined) break;
    for (const owner of owners.get(path) ?? []) {
      if (seen.has(owner)) continue;
      seen.add(owner);
      changed.add(owner);
      queue.push(owner);
    }
  }
}

function expandListChanges(discoveryIndex: Map<string, DiscoveryEntry>, changed: Set<string>): void {
  if (changed.size === 0) return;
  for (const [ruta, entry] of discoveryIndex) {
    if (entry.type === 'list') changed.add(ruta);
  }
}

function rootRelativeOf(raw: string, cwd: string): string {
  const unified = posix(raw);
  const absolute = isAbsolute(unified) ? unified : join(cwd, unified);
  const rel = posix(normalize(relative(cwd, absolute)));
  if (rel === '' || rel === '..' || rel.startsWith('../')) {
    throw new BuildError(`la ruta de build "${raw}" está fuera del proyecto (raíz del proyecto: "${cwd}")`);
  }
  return rel;
}

function resolveRequestedDoc(raw: string, cwd: string, docsByPath: Map<string, BuildDocument>): BuildDocument {
  const path = rootRelativeOf(raw, cwd);
  const doc = docsByPath.get(path);
  if (doc !== undefined) return doc;
  const candidates = [...docsByPath.keys()].filter((p) => basename(p) === basename(path)).sort();
  const hint = candidates.length > 0 ? ` — ¿quisiste decir "${candidates[0]}"?` : '';
  throw new BuildError(`no existe el documento "${raw}" en el proyecto${hint}`);
}

async function collectionClosure(doc: BuildDocument, discoveryIndex: Map<string, DiscoveryEntry>, cwd: string): Promise<string[]> {
  const paths = [...(doc.frontmatter.files ?? [])];
  if (doc.frontmatter.type === 'collection') {
    const collectionFm = discoveryIndex.get(doc.relativePath)?.fm ?? {};
    for (const creator of await resolveCollectionCreatorDocs(doc, discoveryIndex, cwd, collectionFm)) {
      paths.push(creator.relativePath);
    }
  }
  return paths;
}

async function selectDocs(only: string[], allDocs: BuildDocument[], discoveryIndex: Map<string, DiscoveryEntry>, cwd: string): Promise<Set<string>> {
  const docsByPath = new Map(allDocs.map((doc) => [doc.relativePath, doc]));
  const selected = new Set<string>();

  for (const raw of only) {
    const doc = resolveRequestedDoc(raw, cwd, docsByPath);
    selected.add(doc.relativePath);
    if (doc.frontmatter.type !== 'collection' && doc.frontmatter.type !== 'list') continue;
    for (const path of await collectionClosure(doc, discoveryIndex, cwd)) {
      if (docsByPath.has(path)) selected.add(path);
    }
  }

  if (selected.size === 0) {
    throw new BuildError('la selección quedó vacía: ninguna de las rutas pedidas corresponde a un documento del proyecto');
  }
  return selected;
}

function restrictToSelection(
  selection: Set<string>,
  allDocs: BuildDocument[],
  discoveredChanges: Set<string>,
  slugChangedEntries: Map<string, string>,
): BuildDocument[] {
  for (const path of [...discoveredChanges]) {
    if (!selection.has(path)) discoveredChanges.delete(path);
  }

  for (const path of [...slugChangedEntries.keys()]) {
    if (!selection.has(path)) slugChangedEntries.delete(path);
  }
  return allDocs.filter((doc) => selection.has(doc.relativePath));
}

async function discoverDocuments(
  cwd: string,
  options: BuildOptions,
  plan: BuildMetadata,
  prevState: BuildState | null,
  ctx: BuildContext,
  progress: BuildReporter,
): Promise<{
  allDocs: BuildDocument[];
  discoveryIndex: Map<string, DiscoveryEntry>;
  discoveredChanges: Set<string>;
  deletedEntries: Map<string, DiscoveryEntry>;
  slugChangedEntries: Map<string, string>;
  pendingState: BuildState | null;

  selection: Set<string> | undefined;
}> {
  progress.startPhase('discovery');
  const {
    relativePaths,
    changedPaths: discoveredChanges,
    discoveryIndex,
    deletedEntries,
    slugComputer,
    pendingState,
  } = await discover(cwd, {
    full: options.full,
    activeFormats: plan.currentFormats,
    prevState,
    outputDir: ctx.outputDir,
    meta: plan,
  });

  const { slugChangedEntries, changedPaths: slugChangedPaths } = resolveDiscoverSlugs(discoveryIndex, slugComputer);
  for (const path of slugChangedPaths) discoveredChanges.add(path);

  const { collectionOwners } = await postProcessCollections(discoveryIndex, cwd);

  let allDocs = buildDocsFromIndex(relativePaths, discoveryIndex, cwd);

  expandCollectionChanges(discoveredChanges, collectionOwners);
  expandListChanges(discoveryIndex, discoveredChanges);

  const only = selectionOf(options);
  const selection = only === undefined ? undefined : await selectDocs(only, allDocs, discoveryIndex, cwd);
  if (selection !== undefined) allDocs = restrictToSelection(selection, allDocs, discoveredChanges, slugChangedEntries);
  if (options.verbose) {
    for (const doc of allDocs) {
      progress.reportFile({ relativePath: doc.relativePath, phase: 'discovery' });
    }
  }
  progress.completePhase(allDocs.length);
  for (const doc of allDocs) {
    const entry = discoveryIndex.get(doc.relativePath);
    doc.slug = entry?.slug ?? basename(doc.relativePath, '.md');
  }
  return { allDocs, discoveryIndex, discoveredChanges, deletedEntries, slugChangedEntries, pendingState, selection };
}

async function finishBuild(
  deps: {
    progress: BuildReporter;
    siteConfig: SiteConfig;
    outputDir: string;
    effectiveDisabledPreamble: string[];
    needsAssets: boolean;
    runAssets: () => Promise<void>;
    cwd: string;
    pendingState: BuildState | null;
    prevPdfxCache: Record<string, string> | undefined;

    selection: Set<string> | undefined;
  },
  params: {
    processedCount: number;
    cachedCount: number;
    invalidations: string[];
    empty?: boolean;

    pdfOutputs?: string[];
  },
): Promise<BuildSummary> {
  const partial = deps.selection !== undefined;
  if (deps.needsAssets) await deps.runAssets();
  const cache: PdfxCacheHandle = { prev: deps.prevPdfxCache ?? {}, out: {} };

  const pdfxScope = partial ? (params.pdfOutputs ?? []) : undefined;
  const pdfx = await runPdfxOutputValidation(deps.outputDir, deps.siteConfig, { allowBuild: true }, deps.effectiveDisabledPreamble, cache, pdfxScope);
  if (deps.pendingState) deps.pendingState.pdfxCache = cache.out;
  if (pdfx.summaryLine) deps.progress.addSummaryLine(pdfx.summaryLine);
  const formats = params.empty ? [] : computeActiveFormats(deps.siteConfig.format);

  await writeBundle(deps.cwd, deps.outputDir, deps.siteConfig);
  await deps.progress.finish(
    params.processedCount,
    params.cachedCount,
    formats,
    params.empty ? undefined : deps.outputDir,
    params.empty ? undefined : params.invalidations,
  );

  if (!partial) await persistCompletedState(deps.cwd, deps.pendingState);
  const summary: BuildSummary = {
    processed: params.processedCount,
    cached: params.cachedCount,
    formats,
    outputDir: deps.outputDir,
    invalidations: params.empty ? [] : params.invalidations,
  };

  if (deps.selection !== undefined) summary.selected = [...deps.selection].sort();
  return summary;
}

async function clearBuildState(cwd: string): Promise<void> {
  const dir = join(cwd, '.iteraciones');
  const entries = await readdir(dir).catch(() => []);
  for (const entry of entries) {
    if (entry === 'processed-images') continue;
    await rm(join(dir, entry), { recursive: true, force: true });
  }
}

async function prepareEnvironment(
  cwd: string,
  options: BuildOptions,
  siteConfig: SiteConfig,
  plan: BuildMetadata,
  progress: BuildReporter,
): Promise<BuildContext> {
  if (options.full) {
    progress.log('--full: se eliminaron la caché y la salida anterior');
    progress.showCleanup();
  }
  const defaultOutputDir = join(cwd, DIST_FILES_DIR);
  const concurrency = Math.min(Math.max(1, cpus().length - 1), 16);
  const ctx: BuildContext = {
    siteConfig,
    cwd,
    outputDir: options.outputDir ?? defaultOutputDir,
    needsCss: plan.needsCss,
    concurrency,
  };

  if (options.full) {
    await rm(ctx.outputDir, { recursive: true, force: true });
    await clearBuildState(cwd);
  }

  progress.setFormats([
    { phase: 'latex', active: plan.activeFormats.latex },
    { phase: 'pdf', active: plan.activeFormats.pdf },
    { phase: 'html', active: plan.activeFormats.html },
    { phase: 'epub', active: plan.activeFormats.epub },
    { phase: 'markdown', active: plan.activeFormats.markdown },
  ]);
  return ctx;
}

async function formatCleanup(
  ctx: BuildContext,
  plan: BuildMetadata,
  allDocs: BuildDocument[],
  siteConfig: SiteConfig,
  discoveryIndex: Map<string, DiscoveryEntry>,
): Promise<number> {
  let removed = await cleanupRemovedFormats(ctx, allDocs, plan.removedFormats);
  if (plan.activeFormats.pdf) {
    removed += await cleanupCoverImages(ctx, allDocs, siteConfig, discoveryIndex);
  }
  return removed;
}

function planWork(
  plan: BuildMetadata,
  ctx: BuildContext,
  prevState: BuildState | null,
  allDocs: BuildDocument[],
  discoveredChanges: Set<string>,
  log: (msg: string) => void,
  selection?: Set<string>,
): { work: ReturnType<typeof computeWorkSets>; invalidations: string[] } {
  const outputDirChanged = prevState !== null && ctx.outputDir !== prevState.outputDir;
  if (outputDirChanged) {
    log('Directorio de salida modificado — reprocesando todos los documentos');
  }
  const work = computeWorkSets(plan, allDocs, discoveredChanges, outputDirChanged, selection);
  return { work, invalidations: collectInvalidations(plan, outputDirChanged) };
}

async function ensureCachedOutputsComplete(allDocs: BuildDocument[], work: WorkSets, activeFormats: ActiveFormats, outputDir: string): Promise<void> {
  const inWork = new Set(work.workDocList.map((d) => d.relativePath));
  const formatEntries = Object.entries(activeFormats) as [FormatKey, boolean][];

  const producible = (type: string | undefined, fmt: FormatKey): boolean => activeFormats[fmt] === true && docProducesFormat(type, fmt);

  const hasMissingOutput = async (slug: string, dir: string, type: string | undefined): Promise<boolean> => {
    for (const [fmt, active] of formatEntries) {
      if (!active || !producible(type, fmt)) continue;
      const primary = primaryOutputExtension(fmt);
      if (primary !== '' && !(await exists(join(outputDir, dir, `${slug}${primary}`)))) return true;
    }
    return false;
  };

  for (const doc of allDocs) {
    if (inWork.has(doc.relativePath)) continue;
    const slug = htmlSlugFor(doc.relativePath, doc.slug || basename(doc.relativePath, '.md'));
    const dir = dirname(doc.relativePath);
    if (!(await hasMissingOutput(slug, dir, doc.frontmatter.type))) continue;
    for (const [fmt, active] of formatEntries) {
      if (!active || !producible(doc.frontmatter.type, fmt)) continue;
      const key = FORMAT_TO_WORK[fmt];
      work.exportSets[key].push(doc);
      work.workPaths[key]?.add(doc.relativePath);
    }
    work.workDocList.push(doc);
  }
}

async function pipelinePhases(
  progress: BuildReporter,
  ctx: BuildContext,
  plan: BuildMetadata,
  work: ReturnType<typeof computeWorkSets>,
  allDocs: BuildDocument[],
  discoveryIndex: Map<string, DiscoveryEntry>,
  effectiveDisabledPreamble: string[],
  invalidations: string[],
  fallbackReason: string | null,
): Promise<{ processedCount: number; cachedCount: number; invalidations: string[]; pdfOutputs: string[] }> {
  const workDocCount = work.workDocList.length;

  progress.startPhase('render', workDocCount);
  const { processed, pdfOutputs } = await documentPipeline(progress, ctx, plan, work, discoveryIndex, effectiveDisabledPreamble);

  const totalDocs =
    plan.activeFormats.html || plan.activeFormats.pdf || plan.activeFormats.epub || plan.activeFormats.markdown || plan.activeFormats.latex
      ? allDocs.length
      : 0;
  const processedCount = processed.size;
  const cachedCount = totalDocs - processedCount;
  if (invalidations.length === 0 && processedCount > 0) {
    invalidations.push(fallbackReason ?? plural(processedCount, 'documento modificado', 'documentos modificados'));
  }
  return { processedCount, cachedCount, invalidations, pdfOutputs };
}

function licenciasUsadas(discoveryIndex: Map<string, DiscoveryEntry>, siteConfig: SiteConfig): Set<string> {
  const licencias = new Set<string>();
  const porDefecto = licenciaEfectiva({}, siteConfig);
  if (porDefecto !== undefined) licencias.add(porDefecto);
  for (const entry of discoveryIndex.values()) {
    if (!docProducesFormat(entry.type, 'html')) continue;
    const id = licenciaEfectiva(entry.fm ?? {}, siteConfig);
    if (id !== undefined) licencias.add(id);
  }
  return licencias;
}

async function runBuild(cwd: string, options: BuildOptions, progress: BuildReporter, pandocVersion: string): Promise<BuildSummary> {
  const log = (msg: string) => progress.log(msg);

  const partial = selectionOf(options) !== undefined;
  resetImageCache();

  const { siteConfig, effectiveDisabledPreamble } = await resolveEffectiveConfig(cwd);

  if (siteConfig.script === true && !partial) beginScriptCapture(cwd);

  const prevState = options.full ? null : await loadStateFile(cwd);
  const plan = await computeBuildMetadata(cwd, siteConfig, prevState, effectiveDisabledPreamble, pandocVersion);
  logInvalidations(plan, log);

  const ctx = await prepareEnvironment(cwd, options, siteConfig, plan, progress);
  if (ctx.needsCss) await copyAdminSite(ctx.cwd, ctx.outputDir);

  const { allDocs, discoveryIndex, discoveredChanges, deletedEntries, slugChangedEntries, pendingState, selection } = await discoverDocuments(
    cwd,
    options,
    plan,
    prevState,
    ctx,
    progress,
  );

  const necesitaPoppler =
    siteConfig.format?.pdf?.generate === true &&
    (siteConfig.format?.pdf?.coverImage === true ||
      [...discoveryIndex.values()].some((entry) => resolveBooleanField(entry.fm ?? {}, siteConfig.format?.pdf, siteConfig, 'coverImage') === true));
  await assertBuildTools(cwd, siteConfig, { necesitaPoppler });

  const licenseIcons = iconosDeLicencias(licenciasUsadas(discoveryIndex, siteConfig));

  const needsAssets = ctx.needsCss;

  const runAssets = async (): Promise<void> => {
    const { cssHash } = await buildAssets(ctx.outputDir, ctx.cwd, ctx.siteConfig, prevState?.cssHash, licenseIcons);
    if (pendingState) pendingState.cssHash = cssHash;
  };

  const closeDeps = {
    progress,
    siteConfig,
    outputDir: ctx.outputDir,
    effectiveDisabledPreamble,
    needsAssets,
    runAssets,
    cwd,
    pendingState,
    prevPdfxCache: prevState?.pdfxCache,
    selection,
  };

  if (allDocs.length === 0) {
    logWarning(EMPTY_PROJECT_WARNING_NO_DOCS, 'build');
    logWarning(EMPTY_PROJECT_WARNING_INIT, 'build');
    return finishBuild(closeDeps, {
      processedCount: 0,
      cachedCount: 0,
      invalidations: [],
      empty: true,
    });
  }

  let cleanedFiles = await formatCleanup(ctx, plan, allDocs, siteConfig, discoveryIndex);

  const { work, invalidations } = planWork(plan, ctx, prevState, allDocs, discoveredChanges, log, selection);

  await ensureCachedOutputsComplete(allDocs, work, plan.activeFormats, ctx.outputDir);

  if (
    !work.anyWork &&
    work.exportSets.print.length === 0 &&
    work.exportSets.html.length === 0 &&
    work.exportSets.epub.length === 0 &&
    work.exportSets.markdown.length === 0 &&
    work.docsChanged.size === 0
  ) {
    log('Ningún documento modificado — sin cambios');
    return finishBuild(closeDeps, {
      processedCount: 0,
      cachedCount: allDocs.length,
      invalidations,
    });
  }

  cleanedFiles += await cleanupDeletedFiles(ctx, discoveredChanges, allDocs, deletedEntries);
  cleanedFiles += await cleanupSlugChanges(ctx, slugChangedEntries);
  if (cleanedFiles > 0) {
    log(`Limpieza de dist: ${plural(cleanedFiles, 'archivo residual eliminado', 'archivos residuales eliminados')}.`);
  }

  const fallbackReason = prevState === null ? (options.full ? 'build completo desde cero' : 'sin caché previa') : null;
  return finishBuild(
    closeDeps,
    await pipelinePhases(progress, ctx, plan, work, allDocs, discoveryIndex, effectiveDisabledPreamble, invalidations, fallbackReason),
  );
}
