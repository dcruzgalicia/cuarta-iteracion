import { join } from 'node:path';

import { logWarning } from '../lib/logger.js';
import { plural } from '../lib/plural.js';
import { killProcessTree } from '../lib/run.js';
import { convertToPdf } from './export.js';
import type { BuildReporter } from './types.js';

const QUIESCE_TIMEOUT_MS = 30_000;

const QUIESCE_KILL_GRACE_MS = 2_000;

export interface PdfJob {
  dir: string;
  slug: string;
  relativePath: string;
  texPath: string;
  pdfDest: string;
  cover: boolean;

  noBibtex: boolean;
  optimizeForWeb: boolean;
}

export interface PdfJobSink {
  push(job: PdfJob): void;
}

async function waitForWorkers(promises: Promise<void>[], timeoutMs: number): Promise<boolean> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    await Promise.race([
      Promise.allSettled(promises),
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => reject(new Error('pdf-pool: workers vivos tras cancel()')), timeoutMs);
      }),
    ]);
    return true;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

async function executePdfJob(
  job: PdfJob,
  slotIndex: number,
  pdfWorkBase: string,
  biberBase: string,
  inFlightPids: (number | null)[],
  progress: BuildReporter,
  onError: (err: unknown) => void,
): Promise<boolean> {
  const pdfDir = join(pdfWorkBase, job.dir, `slot-${slotIndex}`);
  try {
    await convertToPdf(
      job.texPath,
      job.relativePath,
      pdfDir,
      job.slug,
      join(biberBase, `cache-${slotIndex}`),
      job.pdfDest,
      job.noBibtex,
      (pid) => {
        inFlightPids[slotIndex] = pid;
      },
      job.optimizeForWeb,
    );
  } catch (err) {
    onError(err);
    return false;
  } finally {
    inFlightPids[slotIndex] = null;
  }
  progress.reportFile({ relativePath: job.relativePath, phase: 'pdf' });
  return true;
}

export function createPdfConsumer(
  pdfWorkBase: string,
  biberBase: string,
  maxSlots: number,
  progress: BuildReporter,
): PdfJobSink & {
  pdfJobs: PdfJob[];
  start: () => void;
  markProducerDone: () => void;
  cancel: () => void;
  drain: () => Promise<void>;
  quiesce: (timeoutMs?: number) => Promise<void>;
} {
  const pdfJobs: PdfJob[] = [];
  let producerDone = false;
  let started = false;
  let next = 0;
  let workerPromises: Promise<void>[] = [];
  let firstError: unknown = null;
  let waiters: Array<() => void> = [];
  let pdfPhaseStarted = false;
  const inFlightPids: (number | null)[] = Array.from({ length: maxSlots }, () => null);

  const notify = (): void => {
    const pending = waiters;
    waiters = [];
    for (const resolve of pending) resolve();
  };

  const push = (job: PdfJob): void => {
    pdfJobs.push(job);
    notify();
  };

  const onError = (err: unknown): void => {
    firstError = err;
    producerDone = true;
    pdfJobs.length = 0;
    notify();
  };

  const nextJob = async (): Promise<PdfJob | undefined> => {
    while (firstError === null) {
      const job = pdfJobs[next];
      if (job !== undefined) {
        next++;
        return job;
      }
      if (producerDone) return undefined;
      await new Promise<void>((resolve) => {
        waiters.push(resolve);
      });
    }
    return undefined;
  };

  const worker = async (slotIndex: number): Promise<void> => {
    for (;;) {
      const job = await nextJob();
      if (job === undefined) return;
      ensurePdfPhaseStarted();
      const ok = await executePdfJob(job, slotIndex, pdfWorkBase, biberBase, inFlightPids, progress, onError);
      if (!ok) return;
    }
  };

  const ensurePdfPhaseStarted = (): void => {
    if (!pdfPhaseStarted) {
      pdfPhaseStarted = true;
      progress.startPhase('pdf', 0);
    }
  };

  const start = (): void => {
    if (started) return;
    started = true;
    workerPromises = Array.from({ length: maxSlots }, (_, i) => worker(i));
  };

  const markProducerDone = (): void => {
    producerDone = true;
    notify();
  };

  const cancel = (): void => {
    producerDone = true;
    pdfJobs.length = 0;
    notify();
  };

  const quiesce = async (timeoutMs: number = QUIESCE_TIMEOUT_MS): Promise<void> => {
    if (!started || workerPromises.length === 0) return;
    if (await waitForWorkers(workerPromises, timeoutMs)) return;
    const pids = inFlightPids.filter((pid): pid is number => pid !== null);
    if (pids.length === 0) return;
    logWarning(`terminando ${plural(pids.length, 'compilación PDF en vuelo', 'compilaciones PDF en vuelo')} tras el fallo del build`, 'pdf');
    await Promise.all(pids.map((pid) => killProcessTree(pid)));
    await waitForWorkers(workerPromises, QUIESCE_KILL_GRACE_MS).catch((err) => {
      logWarning(`no se pudo esperar la finalización de los workers del pool PDF: ${String(err)}`, 'pdf');
    });
  };

  const drain = async (): Promise<void> => {
    if (!started) return;
    if (!producerDone) cancel();
    const total = pdfJobs.length;
    const noWorkYet = total > 0 && firstError === null && !pdfPhaseStarted;
    if (noWorkYet) progress.startPhase('pdf', total);
    await Promise.all(workerPromises);
    if (total > 0 && firstError === null) progress.completePhase(total, 'pdf');
    if (firstError !== null) throw firstError;
  };

  return { pdfJobs, push, start, markProducerDone, cancel, drain, quiesce };
}
