import { mkdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';

import type { SiteConfig } from '../config/config-schema.js';
import { DEFAULT_SITE_CONFIG } from '../config/site-config.js';
import { recordSupportCommand } from '../lib/script-recorder.js';
import { type LogoAsset, writeLogoAssets, writeSiteBackground } from './build-assets.js';
import type { BuildMetadata, WorkSets } from './build-planner.js';
import { loadFilterGroups } from './filter-resolver.js';
import { composeHtmlTemplate, type HtmlDocType } from './html-composer.js';
import { loadReferencesCardTemplate } from './html-postprocess.js';
import { applyPrintQueueDynamics, composeLatexTemplate, detectPageSize } from './latex-preamble.js';
import { PDF_WORK_BASE } from './output-layout.js';
import type { PdfJobSink } from './pdf-pool.js';
import { writeIfChanged } from './pipeline-io.js';
import { disableBibliographyWithoutBibFiles, loadPreambleFilters, type PreambleDocType, type PreambleFilter } from './preamble-loader.js';
import type { resolveBibOptions } from './state-bib.js';
import type { BuildContext } from './types.js';

interface EffectiveTemplates {
  biblatexAvailable: boolean;
  pdfxActive: boolean;
  cropActive: boolean;
  pageDimensions: { w: number; h: number; textW: number } | undefined;

  templates: Record<TemplateKind, string>;

  refsCardTemplates: Record<'file' | 'collection' | 'creator' | 'list', string>;
}
export type TemplateKind = 'html' | 'html-collection' | 'html-creator' | 'latex' | 'latex-collection' | 'latex-creator' | 'latex-intervention';

const TEMPLATE_FILES: Record<TemplateKind, string> = {
  html: 'html.html',
  'html-collection': 'html-collection.html',
  'html-creator': 'html-creator.html',
  latex: 'latex.tex',
  'latex-collection': 'latex-collection.tex',
  'latex-creator': 'latex-creator.tex',
  'latex-intervention': 'latex-intervention.tex',
};

function htmlDocTypeOf(kind: TemplateKind): HtmlDocType | undefined {
  if (kind === 'html') return 'file';
  if (kind === 'html-collection') return 'collection';
  if (kind === 'html-creator') return 'creator';
  return undefined;
}

const PREAMBLE_SCOPES: Record<'latex' | 'latex-collection' | 'latex-creator' | 'latex-intervention', PreambleDocType> = {
  latex: 'file',
  'latex-collection': 'collection',
  'latex-creator': 'creator',
  'latex-intervention': 'intervention',
};

export const TEMPLATE_KINDS = Object.keys(TEMPLATE_FILES) as TemplateKind[];
export const templatePathFor = (kind: TemplateKind, templatesDir: string): string => join(templatesDir, TEMPLATE_FILES[kind]);

const PREAMBLE_TEMPLATE_KINDS = ['latex', 'latex-collection', 'latex-creator', 'latex-intervention'] as const satisfies readonly TemplateKind[];

export function latexKindFor(type: PreambleDocType | 'list' | 'menu' | 'announcement' | undefined): TemplateKind {
  if (type === undefined || type === 'file' || type === 'menu' || type === 'announcement') return 'latex';
  if (type === 'list') return 'latex-collection';
  return `latex-${type}`;
}

export function htmlKindFor(type: HtmlDocType): TemplateKind {
  if (type === 'file' || type === 'menu' || type === 'announcement') return 'html';
  if (type === 'list') return 'html-collection';
  return `html-${type}`;
}

interface TemplateInput {
  cwd: string;
  siteConfig: SiteConfig;
  bibFiles: string[];
  effectiveDisabledPreamble: string[];
  preambleFilters?: PreambleFilter[];
}

export async function composeTemplate(kind: TemplateKind, input: TemplateInput): Promise<string> {
  const htmlType = htmlDocTypeOf(kind);
  if (htmlType !== undefined) return composeHtmlTemplate(input.siteConfig, htmlType);
  const scope = PREAMBLE_SCOPES[kind as keyof typeof PREAMBLE_SCOPES];
  const filters = input.preambleFilters ?? (await loadPreambleFilters(input.effectiveDisabledPreamble, input.cwd, scope));

  const dims = detectPageSize(filters);
  return composeLatexTemplate({
    toc: input.siteConfig.toc,
    bibFiles: input.bibFiles,
    preambleFilters: applyPrintQueueDynamics(filters, dims),
    pdfxActive: filters.some((filter) => filter.name === '99-pdfx'),
  });
}

export async function writeEffectiveTemplates(
  ctx: BuildContext,
  plan: BuildMetadata,
  effectiveDisabledPreamble: string[],
): Promise<EffectiveTemplates> {
  const templatesDir = join(ctx.cwd, '.iteraciones', 'templates');
  await mkdir(templatesDir, { recursive: true });
  const refsCardTemplates = {
    file: await loadReferencesCardTemplate('file'),
    collection: await loadReferencesCardTemplate('collection'),
    creator: await loadReferencesCardTemplate('creator'),
    list: await loadReferencesCardTemplate('collection'),
  };
  const state: EffectiveTemplates = {
    biblatexAvailable: true,
    pdfxActive: false,
    cropActive: false,
    pageDimensions: undefined,
    templates: Object.fromEntries(TEMPLATE_KINDS.map((kind) => [kind, templatePathFor(kind, templatesDir)])) as Record<TemplateKind, string>,
    refsCardTemplates,
  };

  const disabledPreamble = disableBibliographyWithoutBibFiles(effectiveDisabledPreamble, plan.bibFiles);
  const tpl: TemplateInput = { cwd: ctx.cwd, siteConfig: ctx.siteConfig, bibFiles: plan.bibFiles, effectiveDisabledPreamble: disabledPreamble };
  const writeTemplate = async (kind: TemplateKind, preambleFilters?: PreambleFilter[]): Promise<void> => {
    const path = state.templates[kind];
    await writeIfChanged(path, await composeTemplate(kind, { ...tpl, preambleFilters }));

    recordSupportCommand('resources', path, ['iteraciones', 'template', kind, '-o', path]);
  };

  if (plan.activeFormats.html) {
    await writeTemplate('html');
    await writeTemplate('html-collection');
    await writeTemplate('html-creator');
  }
  if (plan.generateLatex) {
    for (const kind of PREAMBLE_TEMPLATE_KINDS) {
      const preambleFilters = await loadPreambleFilters(disabledPreamble, ctx.cwd, PREAMBLE_SCOPES[kind]);
      const pageDimensions = detectPageSize(preambleFilters);

      if (PREAMBLE_SCOPES[kind] === 'file') {
        state.biblatexAvailable = preambleFilters.some((f) => f.name === '11-bibliography');
        state.pdfxActive = preambleFilters.some((f) => f.name === '99-pdfx');
        state.cropActive = preambleFilters.some((f) => f.name === '98-crop');
        state.pageDimensions = pageDimensions;
      }
      await writeTemplate(kind, preambleFilters);
    }
  }
  return state;
}

export async function ensureBiberCaches(cwd: string, maxSlots: number): Promise<void> {
  const biberBase = join(cwd, '.iteraciones', 'biber');
  await Promise.all(Array.from({ length: maxSlots }, (_, i) => mkdir(join(biberBase, `cache-${i}`), { recursive: true })));
}

export interface RenderContext {
  ctx: BuildContext;
  plan: BuildMetadata;
  formatCfg: SiteConfig['format'] | undefined;
  lang: string;
  logo: LogoAsset | undefined;
  warnedLangs: Set<string>;
  pdfxActive: boolean;
  cropActive: boolean;
  pageDimensions: { w: number; h: number; textW: number } | undefined;

  announcementImages?: Map<string, string>;
  recentImages?: Map<string, string>;
  siteBackground?: string;
}

export interface ExportContext extends EffectiveTemplates {
  filters: Awaited<ReturnType<typeof loadFilterGroups>>;
  bibOptions: Awaited<ReturnType<typeof resolveBibOptions>>['bibOptions'];
  bibFiles: string[];
  globalBibliography: string | undefined;
  globalCsl: string | undefined;
  pdfWorkDir: string;
}

export interface FormatWorkSets {
  htmlPaths: Set<string>;
  epubPaths: Set<string>;
  mdPaths: Set<string>;
  latexPaths: Set<string>;
  pdfJobs: PdfJobSink;
}

export async function buildPoolContexts(
  ctx: BuildContext,
  plan: BuildMetadata,
  work: WorkSets,
  templates: EffectiveTemplates,
  pdfJobs: PdfJobSink,
): Promise<{ renderCtx: RenderContext; exportCtx: ExportContext; formatWorkSets: FormatWorkSets }> {
  const filters = await loadFilterGroups(ctx.siteConfig, ctx.siteConfig.disabledFilters, ctx.cwd);
  const siteConfig = ctx.siteConfig;
  const lang = siteConfig.language ?? DEFAULT_SITE_CONFIG.language;
  const logo = plan.activeFormats.html ? await writeLogoAssets(ctx.cwd, ctx.outputDir, siteConfig) : undefined;
  const siteBackground = plan.activeFormats.html ? await writeSiteBackground(ctx.cwd, ctx.outputDir, siteConfig) : undefined;
  const renderCtx: RenderContext = {
    ctx,
    plan,
    formatCfg: ctx.siteConfig.format,
    lang,
    logo,
    siteBackground,
    warnedLangs: new Set<string>(),
    pdfxActive: templates.pdfxActive,
    cropActive: templates.cropActive,
    pageDimensions: templates.pageDimensions,
  };
  const exportCtx: ExportContext = {
    filters,
    bibOptions: plan.bibOptions,
    bibFiles: plan.bibFiles,
    globalBibliography: plan.bibOptions?.bibliography,
    globalCsl: siteConfig.csl?.trim() ? resolve(ctx.cwd, siteConfig.csl.trim()) : undefined,
    pdfWorkDir: join(ctx.cwd, PDF_WORK_BASE),
    ...templates,
  };
  const formatWorkSets: FormatWorkSets = {
    htmlPaths: work.workPaths.html,
    epubPaths: work.workPaths.epub,
    mdPaths: work.workPaths.markdown,
    latexPaths: work.workPaths.print,
    pdfJobs,
  };
  return { renderCtx, exportCtx, formatWorkSets };
}
